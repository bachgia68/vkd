export const ADMIN_IMAGES = {
  loginHero: 'https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=1400&q=80&auto=format&fit=crop',
  cmsHero: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1400&q=80&auto=format&fit=crop',
  crmHero: 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=1400&q=80&auto=format&fit=crop',
  warehouseHero: 'https://images.unsplash.com/photo-1553413077-190dd305871c?w=1400&q=80&auto=format&fit=crop',
  growingRegion: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1400&q=80&auto=format&fit=crop',
};

export interface Warehouse {
  code: string;
  name: string;
  type: 'central' | 'showroom';
  province: string;
  lat: number;
  lng: number;
}

export const WAREHOUSES: Warehouse[] = [
  { code: 'KHO-TMR', name: 'Kho trung tâm Tu Mơ Rông', type: 'central', province: 'Kon Tum', lat: 14.99, lng: 107.94 },
  { code: 'KHO-DN', name: 'Kho trung tâm Đà Nẵng', type: 'central', province: 'Đà Nẵng', lat: 16.05, lng: 108.2 },
  { code: 'SR-DN', name: 'Showroom Võ Kim Đường - Đà Nẵng', type: 'showroom', province: 'Đà Nẵng', lat: 16.07, lng: 108.22 },
  { code: 'SR-HN', name: 'Showroom VKD - Hà Nội', type: 'showroom', province: 'Hà Nội', lat: 21.03, lng: 105.85 },
  { code: 'SR-HCM', name: 'Showroom VKD - TP.HCM', type: 'showroom', province: 'TP.HCM', lat: 10.78, lng: 106.7 },
];

export interface InventoryRow {
  sku: string;
  name: string;
  threshold: number;
  stock: Record<string, number>; // warehouse code -> qty
}

export const INVENTORY: InventoryRow[] = [
  { sku: 'VKD-SP1', name: 'Sâm tươi Thượng Hạng (10 năm)', threshold: 5, stock: { 'KHO-TMR': 14, 'KHO-DN': 22, 'SR-DN': 4, 'SR-HN': 6, 'SR-HCM': 9 } },
  { sku: 'VKD-SP2', name: 'Sâm tươi 7 năm tuổi', threshold: 5, stock: { 'KHO-TMR': 30, 'KHO-DN': 41, 'SR-DN': 8, 'SR-HN': 3, 'SR-HCM': 11 } },
  { sku: 'VKD-TR3', name: 'Trà túi lọc hồng sâm', threshold: 20, stock: { 'KHO-TMR': 120, 'KHO-DN': 210, 'SR-DN': 44, 'SR-HN': 38, 'SR-HCM': 52 } },
  { sku: 'VKD-ML4', name: 'Mật ong ngâm sâm', threshold: 10, stock: { 'KHO-TMR': 60, 'KHO-DN': 88, 'SR-DN': 12, 'SR-HN': 4, 'SR-HCM': 15 } },
  { sku: 'VKD-VN5', name: 'Viên nang chiết xuất MR2', threshold: 15, stock: { 'KHO-TMR': 95, 'KHO-DN': 140, 'SR-DN': 18, 'SR-HN': 9, 'SR-HCM': 24 } },
  { sku: 'VKD-RS6', name: 'Rượu sâm hạ thổ 3 năm', threshold: 5, stock: { 'KHO-TMR': 18, 'KHO-DN': 26, 'SR-DN': 3, 'SR-HN': 2, 'SR-HCM': 7 } },
];

export const PROVINCE_COORDS: Record<string, { lat: number; lng: number }> = {
  'Đà Nẵng': { lat: 16.05, lng: 108.2 },
  'Hà Nội': { lat: 21.03, lng: 105.85 },
  'TP.HCM': { lat: 10.78, lng: 106.7 },
  Huế: { lat: 16.46, lng: 107.59 },
  'Kon Tum': { lat: 14.35, lng: 108.0 },
  'Cần Thơ': { lat: 10.03, lng: 105.79 },
};

export const QR_HEATMAP = [
  { region: 'TP.HCM', count: 312, suspect: false },
  { region: 'Hà Nội', count: 266, suspect: false },
  { region: 'Đà Nẵng', count: 184, suspect: false },
  { region: 'Cần Thơ', count: 47, suspect: true },
  { region: 'Kon Tum', count: 39, suspect: false },
  { region: 'Hải Phòng', count: 22, suspect: true },
];

export type CustomerSegment = 'active_vip' | 'lapsed_vip' | 'active';

export interface Customer {
  id: number;
  name: string;
  tier: 'Platinum' | 'Gold' | 'Silver';
  spend: number;
  last: string;
  segment: CustomerSegment;
  devices: number;
}

export const CUSTOMERS: Customer[] = [
  { id: 1, name: 'Trần Bảo Long', tier: 'Platinum', spend: 342000000, last: '20/04/2026', segment: 'lapsed_vip', devices: 2 },
  { id: 2, name: 'Nguyễn Thảo Vy', tier: 'Gold', spend: 186500000, last: '11/07/2026', segment: 'active_vip', devices: 1 },
  { id: 3, name: 'Phạm Minh Đức', tier: 'Gold', spend: 96000000, last: '02/05/2026', segment: 'lapsed_vip', devices: 1 },
  { id: 4, name: 'Lê Thu Hà', tier: 'Silver', spend: 34500000, last: '14/07/2026', segment: 'active', devices: 1 },
  { id: 5, name: 'Vũ Anh Khoa', tier: 'Platinum', spend: 410000000, last: '09/07/2026', segment: 'active_vip', devices: 3 },
];

export const CONSENT_LOG: [string, string, string, string][] = [
  ['16/01/2026', 'Đồng ý xử lý dữ liệu sức khỏe', 'App Elite Club', 'Đã ghi nhận'],
  ['16/01/2026', 'Đồng ý nhận ZNS/Marketing', 'Zalo OA', 'Đã ghi nhận'],
  ['02/06/2026', 'Yêu cầu xem dữ liệu cá nhân', 'Email hỗ trợ', 'Đã xử lý'],
];

export const BANNED_KEYWORDS = ['đặc trị', 'chữa khỏi hoàn toàn', 'chữa khỏi', 'thần dược', 'thay thế thuốc chữa bệnh'];
export const MANDATORY_DISCLAIMER =
  'Sản phẩm này không phải là thuốc và không có tác dụng thay thế thuốc chữa bệnh. Hiệu quả có thể khác nhau tùy cơ địa mỗi người.';

export type ArticleStage = 0 | 1 | 2;
export interface Article {
  id: number;
  title: string;
  stage: ArticleStage;
  body: string;
}

export const ARTICLES: Article[] = [
  {
    id: 1,
    title: 'Majonoside-R2 và vai trò với hệ miễn dịch',
    stage: 1,
    body: 'Sâm Ngọc Linh chứa hàm lượng Majonoside-R2 (MR2) cao, một saponin đặc hữu được nhiều nghiên cứu sơ bộ quan tâm. Sản phẩm hỗ trợ tăng cường thể trạng, không phải là thuốc đặc trị bệnh nào.',
  },
  {
    id: 2,
    title: 'Kinh nghiệm chọn sâm tươi Tu Mơ Rông chuẩn',
    stage: 2,
    body: 'Bài viết hướng dẫn khách hàng nhận biết sâm Ngọc Linh tự nhiên qua đường vân ngọc, mắt đốt và mùi hương đặc trưng vùng Tu Mơ Rông.',
  },
  {
    id: 3,
    title: 'Sâm Ngọc Linh chữa khỏi hoàn toàn suy nhược cơ thể?',
    stage: 0,
    body: 'Nhiều khách hàng phản hồi sau khi dùng sâm Ngọc Linh đặc trị chứng mất ngủ và chữa khỏi hoàn toàn tình trạng suy nhược kéo dài nhiều năm.',
  },
  {
    id: 4,
    title: 'Câu chuyện vùng trồng: Nam Trà My mùa thu hoạch',
    stage: 2,
    body: 'Ghi chép từ vùng trồng Nam Trà My, Quảng Nam trong mùa thu hoạch chính vụ, nơi khí hậu và độ cao tạo nên chất lượng sâm đặc trưng.',
  },
];

export function fmt(n: number) {
  return new Intl.NumberFormat('vi-VN').format(n);
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
}
