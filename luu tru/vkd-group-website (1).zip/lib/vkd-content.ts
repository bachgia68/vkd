export type Lang = 'en' | 'vi'

export const products = [
  {
    id: 'sam-thai-lat',
    image: '/vkd/prod-thailat.png',
    priceVnd: '2.500.000 ₫',
    priceUsd: '$98',
    saponin: '12% MR2 Saponin',
    name: {
      en: 'Ngoc Linh Ginseng Slices in Honey',
      vi: 'Sâm Ngọc Linh thái lát ngâm mật ong',
    },
    category: { en: 'Root & Extract', vi: 'Sâm củ' },
    alt: 'VKD Group Premium Ngoc Linh Ginseng Slices Preserved in Wild Honey',
  },
  {
    id: 'ruou-thien-huong',
    image: '/vkd/prod-ruou1.png',
    priceVnd: '1.750.000 ₫',
    priceUsd: '$69',
    saponin: '10-Year Aged',
    name: {
      en: 'Ngoc De \u2013 Thien Huong 750ml',
      vi: 'Rượu Ngọc Đế - Thiên Hương 750ml',
    },
    category: { en: 'Ginseng Liquor', vi: 'Rượu Ngọc Đế' },
    alt: 'VKD Group Ngoc De Thien Huong Ngoc Linh Ginseng Liquor 750ml',
  },
  {
    id: 'ruou-12-nam',
    image: '/vkd/prod-ruou12.png',
    priceVnd: '3.230.000 ₫',
    priceUsd: '$127',
    saponin: '12-Year Aged',
    name: {
      en: 'Ngoc De 12-Year Reserve 500ml',
      vi: 'Rượu Ngọc Đế 12 năm 500ml',
    },
    category: { en: 'Ginseng Liquor', vi: 'Rượu Ngọc Đế' },
    alt: 'VKD Group Ngoc De 12 Year Reserve Ngoc Linh Ginseng Liquor',
  },
  {
    id: 'tra-sam',
    image: '/vkd/prod-tra.png',
    priceVnd: '480.000 ₫',
    priceUsd: '$19',
    saponin: 'Daily Infusion',
    name: {
      en: 'Ngoc Linh Ginseng Tea',
      vi: 'Trà Sâm Ngọc Linh',
    },
    category: { en: 'Herbal Tea', vi: 'Trà sâm' },
    alt: 'VKD Group Premium Ngoc Linh Ginseng Herbal Tea',
  },
  {
    id: 'panaxx',
    image: '/vkd/ruou.jpg',
    priceVnd: '26.000 ₫',
    priceUsd: '$1.2',
    saponin: 'Energy & Vitality',
    name: {
      en: 'PanaxX Super Drink 190ml',
      vi: 'Nước Cốt Sâm PanaxX 190ml',
    },
    category: { en: 'Energy Drink', vi: 'Nước tăng lực' },
    alt: 'VKD Group PanaxX Ngoc Linh Ginseng Energy Super Drink 190ml',
  },
  {
    id: 'my-pham',
    image: '/vkd/prod-mypham1.png',
    priceVnd: '3.230.000 ₫',
    priceUsd: '$127',
    saponin: 'Youth & Radiance',
    name: {
      en: "Pn's Choice Skin Recovery Set",
      vi: 'Bộ phục hồi da Pn\u2019s Choice',
    },
    category: { en: 'Micellar Cosmetics', vi: 'Mỹ phẩm PN\u2019s' },
    alt: 'VKD Group Pns Choice Ngoc Linh Ginseng Micellar Skincare Recovery Set',
  },
]

export const certificates = [
  { image: '/vkd/cert-cgmp.jpg', title: 'CGMP', alt: 'VKD Group CGMP Manufacturing Certificate' },
  { image: '/vkd/cert-iso9001.jpg', title: 'ISO 9001:2015', alt: 'VKD Group ISO 9001 2015 Quality Certificate' },
  { image: '/vkd/cert-haccp.jpg', title: 'HACCP CODEX 2020', alt: 'VKD Group HACCP Codex 2020 Food Safety Certificate' },
]

export const showrooms = [
  {
    city: { en: 'Ha Noi', vi: 'Hà Nội' },
    address: 'Số 44 Ngõ 120 - Trường Chinh, Phường Kim Liên, TP Hà Nội',
    phone: '1800.28.28.66',
    hours: '08:00 - 20:00',
  },
  {
    city: { en: 'Ho Chi Minh City', vi: 'Hồ Chí Minh' },
    address: 'Số 30 đường số 9, KDC Vạn Phúc, P. Hiệp Bình, TP Hồ Chí Minh',
    phone: '0862.09.91.45',
    hours: '08:00 - 20:00',
  },
  {
    city: { en: 'Da Nang', vi: 'Đà Nẵng' },
    address: '359 Nguyễn Văn Linh, phường Thanh Khê, TP Đà Nẵng',
    phone: '1800.28.28.66',
    hours: '08:00 - 20:00',
  },
  {
    city: { en: 'Phnom Penh, Cambodia', vi: 'Campuchia' },
    address: '49E, Street 139, Sangkat Veal Vong, Khan 7 Makara, Phnom Penh',
    phone: '1800.28.28.66',
    hours: '08:00 - 20:00',
  },
  {
    city: { en: 'Udon Thani, Thailand', vi: 'Thái Lan' },
    address: '999/9 Cluster 4, Thanon Mittraphap, Mueang Udon Thani, 41000',
    phone: '1800.28.28.66',
    hours: '08:00 - 20:00',
  },
  {
    city: { en: 'Nghe An', vi: 'Nghệ An' },
    address: 'Số 71 Nguyễn Văn Cừ, Trường Thi, TP Vinh, Nghệ An',
    phone: '0973.89.59.85',
    hours: '08:00 - 20:00',
  },
]

export const testimonials = [
  {
    name: 'Uyên Nhi',
    role: { en: 'Office Professional', vi: 'Nhân viên văn phòng' },
    quote: {
      en: 'I naturally run hot and break out easily, and office work left me no time for my health. Ngoc Linh ginseng changed my daily balance completely.',
      vi: 'Tôi vốn là người có cơ địa nóng trong hay bị nổi mụn. Công việc văn phòng khiến tôi không có nhiều thời gian chăm sóc sức khỏe.',
    },
  },
  {
    name: 'Quản Duy Tân',
    role: { en: 'Long-haul Driver', vi: 'Tài xế đường dài' },
    quote: {
      en: 'I used to rely on sugary energy drinks to stay awake on long drives. PanaxX keeps me alert without the crash.',
      vi: 'Tôi thường xuyên lái xe đường dài, phải dùng nhiều nước tăng lực. PanaxX giúp tôi tỉnh táo mà không mệt.',
    },
  },
  {
    name: 'Thảo Phương',
    role: { en: 'Beauty Specialist', vi: 'Chuyên viên làm đẹp' },
    quote: {
      en: 'Skincare is essential to my profession. The Pn\u2019s Choice line with Ngoc Linh ginseng extract gave my skin a visible glow.',
      vi: 'Chăm sóc làn da vô cùng quan trọng với mình. Bộ sản phẩm Pn\u2019s Choice chiết xuất Sâm Ngọc Linh cho da căng bóng rõ rệt.',
    },
  },
]

export const dict = {
  nav: {
    home: { en: 'Home', vi: 'Trang Chủ' },
    about: { en: 'About', vi: 'Giới Thiệu' },
    products: { en: 'Products', vi: 'Sản Phẩm' },
    research: { en: 'Research', vi: 'Nghiên Cứu' },
    showrooms: { en: 'Showrooms', vi: 'Hệ Thống' },
    contact: { en: 'Contact', vi: 'Liên Hệ' },
    cta: { en: 'Explore Now', vi: 'Khám Phá Ngay' },
  },
  hero: {
    eyebrow: {
      en: 'Vietnam\u2019s National Treasure \u00b7 Panax vietnamensis',
      vi: 'Quốc Bảo Việt Nam \u00b7 Panax vietnamensis',
    },
    title: {
      en: 'The Billion-Year Treasure of Vietnam\u2019s Deep Forest',
      vi: 'Báu Vật Ngàn Năm Từ Đại Ngàn Việt Nam',
    },
    subtitle: {
      en: 'VKD Group pioneers the preservation and global development of Ngoc Linh Ginseng \u2014 the world\u2019s richest ginseng, bearing more than 52 rare saponins.',
      vi: 'Tập Đoàn Y Dược Sâm Ngọc Linh Việt Nam tiên phong bảo tồn và đưa Sâm Ngọc Linh \u2014 loài sâm quý với hơn 52 loại saponin \u2014 vươn ra thế giới.',
    },
    primary: { en: 'Discover the Collection', vi: 'Khám Phá Bộ Sưu Tập' },
    secondary: { en: 'Our Heritage', vi: 'Về Chúng Tôi' },
  },
  heritage: {
    eyebrow: { en: 'Heritage & Science', vi: 'Di Sản & Khoa Học' },
    title: {
      en: 'Medical authority rooted in the Ngoc Linh mountains',
      vi: 'Uy tín y dược khởi nguồn từ đỉnh Ngọc Linh',
    },
    body: {
      en: 'Grown between 1,500 and 2,200 metres in the pristine forests of Kon Tum and Quang Nam, Ngoc Linh Ginseng is cultivated, studied and refined under strict pharmaceutical standards.',
      vi: 'Sinh trưởng ở độ cao 1.500 \u2013 2.200m trong rừng nguyên sinh Kon Tum và Quảng Nam, Sâm Ngọc Linh được nuôi trồng, nghiên cứu và tinh chế theo tiêu chuẩn dược phẩm nghiêm ngặt.',
    },
    stats: [
      { value: '52+', label: { en: 'Rare saponin types', vi: 'Loại saponin quý' } },
      { value: 'MR2', label: { en: 'Signature Majonoside R2', vi: 'Hoạt chất Majonoside R2' } },
      { value: '2,200m', label: { en: 'Cultivation altitude', vi: 'Độ cao vùng trồng' } },
      { value: '7', label: { en: 'International showrooms', vi: 'Showroom quốc tế' } },
    ],
  },
  featured: {
    eyebrow: { en: 'The Collection', vi: 'Bộ Sưu Tập' },
    title: { en: 'Featured Products', vi: 'Sản Phẩm Nổi Bật' },
    subtitle: {
      en: 'Curated expressions of Ngoc Linh Ginseng \u2014 from aged reserve liquors to daily vitality.',
      vi: 'Tinh hoa Sâm Ngọc Linh \u2014 từ rượu ủ lâu năm đến sản phẩm chăm sóc sức khỏe hằng ngày.',
    },
    view: { en: 'View Product', vi: 'Xem Sản Phẩm' },
    viewAll: { en: 'View All Products', vi: 'Xem Tất Cả' },
  },
  certificates: {
    eyebrow: { en: 'Verified Quality', vi: 'Chất Lượng Xác Thực' },
    title: { en: 'Certifications & Recognition', vi: 'Chứng Chỉ Công Nhận' },
    subtitle: {
      en: 'Every product is backed by internationally recognised pharmaceutical and food-safety standards.',
      vi: 'Mọi sản phẩm đều được chứng nhận theo tiêu chuẩn dược phẩm và an toàn thực phẩm quốc tế.',
    },
  },
  showrooms: {
    eyebrow: { en: 'Vo Kim Duong Network', vi: 'Chuỗi Võ Kim Đường' },
    title: { en: 'Showroom Network', vi: 'Hệ Thống Showroom' },
    subtitle: {
      en: 'Experience Ngoc Linh Ginseng across our flagship showrooms in Vietnam and abroad.',
      vi: 'Trải nghiệm Sâm Ngọc Linh tại hệ thống showroom Võ Kim Đường trong nước và quốc tế.',
    },
    hours: { en: 'Open daily', vi: 'Mở cửa hằng ngày' },
  },
  testimonials: {
    eyebrow: { en: 'From Our Clients', vi: 'Cảm Nhận Khách Hàng' },
    title: { en: 'Trusted by discerning customers', vi: 'Được khách hàng tin tưởng' },
  },
  footer: {
    company: {
      en: 'VKD GROUP \u2013 NGOC LINH GINSENG VIETNAM MEDICAL GROUP',
      vi: 'CÔNG TY CỔ PHẦN TẬP ĐOÀN Y DƯỢC SÂM NGỌC LINH VIỆT NAM',
    },
    address: 'Tòa nhà 44/120 Trường Chinh, Phường Kim Liên, Thành Phố Hà Nội',
    about: { en: 'About Us', vi: 'Về Chúng Tôi' },
    aboutLinks: {
      en: ['Group Introduction', 'Foreword', 'Core Values', 'Development Strategy'],
      vi: ['Giới thiệu tập đoàn', 'Thư ngỏ', 'Giá trị cốt lõi', 'Chiến lược phát triển'],
    },
    connect: { en: 'Connect', vi: 'Kết Nối Thêm' },
    connectLinks: {
      en: ['Domestic News', 'International News', 'Research & Development'],
      vi: ['Tin trong nước', 'Tin ngoài nước', 'Nghiên cứu và phát triển'],
    },
    rights: {
      en: 'All rights reserved.',
      vi: 'Bảo lưu mọi quyền.',
    },
  },
}
