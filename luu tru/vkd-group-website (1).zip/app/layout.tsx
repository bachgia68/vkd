import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Playfair_Display, Inter } from 'next/font/google'
import './globals.css'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://samngoclinhvkdgroup.com'),
  title: {
    default: 'VKD Group | Ngoc Linh Ginseng Vietnam Medical Group',
    template: '%s | VKD Group',
  },
  description:
    'Tập Đoàn Y Dược Sâm Ngọc Linh Việt Nam — pioneering the preservation and global development of Ngoc Linh Ginseng, Vietnam\u2019s national treasure with 52+ rare saponins.',
  keywords: [
    'Ngoc Linh Ginseng',
    'Sâm Ngọc Linh',
    'VKD Group',
    'Panax vietnamensis',
    'Majonoside R2',
    'PanaxX',
    'Vietnamese ginseng',
  ],
  generator: 'v0.app',
  openGraph: {
    type: 'website',
    title: 'VKD Group | Ngoc Linh Ginseng Vietnam Medical Group',
    description:
      'The billion-year treasure of Vietnam\u2019s deep forest. Premium Ngoc Linh Ginseng products crafted for the world.',
    siteName: 'VKD Group',
    images: [{ url: '/vkd/hero.jpg', width: 1920, height: 1080 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'VKD Group | Ngoc Linh Ginseng Vietnam Medical Group',
    description:
      'The billion-year treasure of Vietnam\u2019s deep forest. Premium Ngoc Linh Ginseng products crafted for the world.',
    images: ['/vkd/hero.jpg'],
  },
  icons: {
    icon: '/vkd/logo.png',
    apple: '/vkd/logo.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#0B2F1D',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      className={`${playfair.variable} ${inter.variable} bg-background`}
    >
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
