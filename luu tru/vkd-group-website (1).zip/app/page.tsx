import { LanguageProvider } from '@/components/vkd/language-provider'
import { Navbar } from '@/components/vkd/navbar'
import { Hero } from '@/components/vkd/hero'
import { Heritage } from '@/components/vkd/heritage'
import { Products } from '@/components/vkd/products'
import { Research } from '@/components/vkd/research'
import { Certificates } from '@/components/vkd/certificates'
import { Showrooms } from '@/components/vkd/showrooms'
import { Testimonials } from '@/components/vkd/testimonials'
import { Footer } from '@/components/vkd/footer'

export default function Page() {
  return (
    <LanguageProvider>
      <Navbar />
      <main>
        <Hero />
        <Heritage />
        <Products />
        <Research />
        <Certificates />
        <Showrooms />
        <Testimonials />
      </main>
      <Footer />
    </LanguageProvider>
  )
}
