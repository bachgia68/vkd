'use client'

import Image from 'next/image'
import { useEffect, useState } from 'react'
import { Menu, X, ShoppingBag } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict } from '@/lib/vkd-content'

const links = [
  { key: 'about', href: '#heritage' },
  { key: 'products', href: '#products' },
  { key: 'research', href: '#research' },
  { key: 'showrooms', href: '#showrooms' },
  { key: 'contact', href: '#contact' },
] as const

export function Navbar() {
  const { lang, setLang, t } = useLanguage()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/90 shadow-sm backdrop-blur-md'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-8">
        <a href="#top" className="flex items-center gap-3">
          <span
            className={`relative block h-11 w-11 overflow-hidden rounded-full ring-1 transition-colors ${
              scrolled ? 'ring-border bg-card' : 'ring-white/30 bg-white/90'
            }`}
          >
            <Image
              src="/vkd/logo.png"
              alt="VKD Group - Ngoc Linh Ginseng Vietnam Medical Group logo"
              fill
              sizes="44px"
              className="object-contain p-1"
              priority
            />
          </span>
          <span
            className={`flex flex-col leading-tight transition-colors ${
              scrolled ? 'text-forest' : 'text-white'
            }`}
          >
            <span className="font-serif text-base font-semibold tracking-wide">
              VKD GROUP
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] opacity-80">
              Ngoc Linh Ginseng
            </span>
          </span>
        </a>

        <div className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <a
              key={l.key}
              href={l.href}
              className={`text-sm font-medium tracking-wide transition-colors hover:text-accent ${
                scrolled ? 'text-forest' : 'text-white/90'
              }`}
            >
              {t(dict.nav[l.key])}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <div
            className={`hidden items-center rounded-full border p-0.5 text-xs font-semibold sm:flex ${
              scrolled ? 'border-border' : 'border-white/40'
            }`}
          >
            {(['en', 'vi'] as const).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                className={`rounded-full px-2.5 py-1 uppercase transition-colors ${
                  lang === code
                    ? 'bg-accent text-accent-foreground'
                    : scrolled
                      ? 'text-forest'
                      : 'text-white'
                }`}
                aria-pressed={lang === code}
              >
                {code}
              </button>
            ))}
          </div>

          <a
            href="#products"
            className={`hidden items-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition-colors md:inline-flex ${
              scrolled
                ? 'bg-forest text-forest-foreground hover:bg-forest/90'
                : 'bg-accent text-accent-foreground hover:bg-accent/90'
            }`}
          >
            <ShoppingBag className="h-4 w-4" />
            {t(dict.nav.cta)}
          </a>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className={`inline-flex h-10 w-10 items-center justify-center rounded-full lg:hidden ${
              scrolled ? 'text-forest' : 'text-white'
            }`}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="border-t border-border bg-background/95 backdrop-blur-md lg:hidden">
          <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-4">
            {links.map((l) => (
              <a
                key={l.key}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-2.5 text-sm font-medium text-forest hover:bg-secondary"
              >
                {t(dict.nav[l.key])}
              </a>
            ))}
            <div className="mt-2 flex items-center gap-2 px-3">
              {(['en', 'vi'] as const).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setLang(code)}
                  className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase ${
                    lang === code
                      ? 'border-accent bg-accent text-accent-foreground'
                      : 'border-border text-forest'
                  }`}
                >
                  {code}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
