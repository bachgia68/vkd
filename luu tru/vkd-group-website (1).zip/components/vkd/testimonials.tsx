'use client'

import { Star, Quote } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict, testimonials } from '@/lib/vkd-content'

export function Testimonials() {
  const { t } = useLanguage()

  return (
    <section className="bg-background py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
            {t(dict.testimonials.eyebrow)}
          </span>
          <h2 className="mt-4 text-balance font-serif text-3xl font-semibold text-forest md:text-4xl">
            {t(dict.testimonials.title)}
          </h2>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {testimonials.map((item) => (
            <figure
              key={item.name}
              className="relative flex flex-col rounded-sm border border-border bg-card p-8"
            >
              <Quote className="absolute right-6 top-6 h-8 w-8 text-accent/20" />
              <div className="flex gap-0.5 text-accent">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-5 flex-1 text-pretty leading-relaxed text-muted-foreground">
                {t(item.quote)}
              </blockquote>
              <figcaption className="mt-6 border-t border-border pt-5">
                <div className="font-serif text-base font-semibold text-forest">
                  {item.name}
                </div>
                <div className="text-sm text-muted-foreground">
                  {t(item.role)}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
