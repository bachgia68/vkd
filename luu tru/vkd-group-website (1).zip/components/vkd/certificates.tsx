'use client'

import Image from 'next/image'
import { useLanguage } from './language-provider'
import { certificates, dict } from '@/lib/vkd-content'

export function Certificates() {
  const { t } = useLanguage()

  return (
    <section className="bg-background py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
            {t(dict.certificates.eyebrow)}
          </span>
          <h2 className="mt-4 text-balance font-serif text-3xl font-semibold text-forest md:text-4xl">
            {t(dict.certificates.title)}
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            {t(dict.certificates.subtitle)}
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          {certificates.map((c) => (
            <figure
              key={c.title}
              className="group overflow-hidden rounded-sm border border-border bg-card"
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
                <Image
                  src={c.image}
                  alt={c.alt}
                  fill
                  sizes="(max-width: 640px) 100vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <figcaption className="border-t border-border px-5 py-4 text-center font-serif text-base font-semibold text-forest">
                {c.title}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
