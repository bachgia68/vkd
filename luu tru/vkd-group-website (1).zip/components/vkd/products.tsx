'use client'

import Image from 'next/image'
import { ArrowUpRight, ShieldCheck } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict, products } from '@/lib/vkd-content'

export function Products() {
  const { t } = useLanguage()

  return (
    <section id="products" className="scroll-mt-20 bg-secondary py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
            {t(dict.featured.eyebrow)}
          </span>
          <h2 className="mt-4 text-balance font-serif text-3xl font-semibold text-forest md:text-4xl lg:text-5xl">
            {t(dict.featured.title)}
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            {t(dict.featured.subtitle)}
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => (
            <article
              key={p.id}
              className="group flex flex-col overflow-hidden rounded-sm border border-border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-background">
                <Image
                  src={p.image}
                  alt={p.alt}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-contain p-6 transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-4 top-4 inline-flex items-center gap-1 rounded-full bg-forest/90 px-3 py-1 text-[11px] font-medium text-forest-foreground backdrop-blur-sm">
                  <ShieldCheck className="h-3 w-3 text-accent" />
                  {p.saponin}
                </span>
              </div>

              <div className="flex flex-1 flex-col p-6">
                <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-accent">
                  {t(p.category)}
                </span>
                <h3 className="mt-2 font-serif text-lg font-semibold leading-snug text-forest">
                  {t(p.name)}
                </h3>
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <div className="font-serif text-xl font-semibold text-forest">
                      {p.priceVnd}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {p.priceUsd} USD
                    </div>
                  </div>
                </div>
                <a
                  href="#contact"
                  className="mt-5 inline-flex items-center justify-center gap-2 rounded-full border border-forest px-5 py-2.5 text-sm font-semibold text-forest transition-colors group-hover:bg-forest group-hover:text-forest-foreground"
                >
                  {t(dict.featured.view)}
                  <ArrowUpRight className="h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 rounded-full bg-forest px-8 py-3.5 text-sm font-semibold text-forest-foreground transition-colors hover:bg-forest/90"
          >
            {t(dict.featured.viewAll)}
            <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  )
}
