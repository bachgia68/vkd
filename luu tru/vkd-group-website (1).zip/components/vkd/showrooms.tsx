'use client'

import Image from 'next/image'
import { MapPin, Phone, Clock } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict, showrooms } from '@/lib/vkd-content'

export function Showrooms() {
  const { t } = useLanguage()

  return (
    <section id="showrooms" className="scroll-mt-20 bg-secondary py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.2fr] lg:items-center lg:gap-16">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
              {t(dict.showrooms.eyebrow)}
            </span>
            <h2 className="mt-4 text-balance font-serif text-3xl font-semibold text-forest md:text-4xl lg:text-5xl">
              {t(dict.showrooms.title)}
            </h2>
            <p className="mt-4 max-w-md text-pretty leading-relaxed text-muted-foreground">
              {t(dict.showrooms.subtitle)}
            </p>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="relative aspect-[3/2] overflow-hidden rounded-sm">
                <Image
                  src="/vkd/showroom-thailan.png"
                  alt="VKD Group Vo Kim Duong luxury showroom interior in Udon Thani, Thailand"
                  fill
                  sizes="(max-width: 1024px) 50vw, 25vw"
                  className="object-cover"
                />
              </div>
              <div className="relative aspect-[3/2] overflow-hidden rounded-sm">
                <Image
                  src="/vkd/showroom-campuchia.webp"
                  alt="VKD Group Vo Kim Duong flagship showroom in Phnom Penh, Cambodia"
                  fill
                  sizes="(max-width: 1024px) 50vw, 25vw"
                  className="object-cover"
                />
              </div>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {showrooms.map((s) => (
              <article
                key={t(s.city)}
                className="rounded-sm border border-border bg-card p-6 transition-colors hover:border-accent"
              >
                <h3 className="font-serif text-lg font-semibold text-forest">
                  {t(s.city)}
                </h3>
                <div className="mt-4 space-y-3 text-sm text-muted-foreground">
                  <p className="flex items-start gap-2.5">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    <span>{s.address}</span>
                  </p>
                  <p className="flex items-center gap-2.5">
                    <Phone className="h-4 w-4 shrink-0 text-accent" />
                    <span>{s.phone}</span>
                  </p>
                  <p className="flex items-center gap-2.5">
                    <Clock className="h-4 w-4 shrink-0 text-accent" />
                    <span>
                      {t(dict.showrooms.hours)} {'\u00b7'} {s.hours}
                    </span>
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
