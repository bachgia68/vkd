'use client'

import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict } from '@/lib/vkd-content'

export function Hero() {
  const { t } = useLanguage()

  return (
    <section id="top" className="relative min-h-screen overflow-hidden">
      <Image
        src="/vkd/hero.jpg"
        alt="Ngoc Linh Ginseng cultivated in the deep primeval forests of Kon Tum, Vietnam"
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-forest/80 via-forest/55 to-forest/85" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(11,47,29,0.35)_100%)]" />

      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col items-start justify-center px-4 pt-24 pb-16 md:px-8">
        <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/50 bg-forest/30 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.2em] text-accent backdrop-blur-sm">
          {t(dict.hero.eyebrow)}
        </span>

        <h1 className="max-w-4xl text-balance font-serif text-4xl font-semibold leading-[1.1] text-white sm:text-5xl md:text-6xl lg:text-7xl">
          {t(dict.hero.title)}
        </h1>

        <p className="mt-6 max-w-2xl text-pretty text-base leading-relaxed text-white/85 md:text-lg">
          {t(dict.hero.subtitle)}
        </p>

        <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
          <a
            href="#products"
            className="group inline-flex items-center justify-center gap-2 rounded-full bg-accent px-8 py-3.5 text-sm font-semibold text-accent-foreground transition-colors hover:bg-accent/90"
          >
            {t(dict.hero.primary)}
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </a>
          <a
            href="#heritage"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-white/40 px-8 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
          >
            {t(dict.hero.secondary)}
          </a>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-6 border-t border-white/15 pt-8 sm:gap-12">
          {dict.heritage.stats.slice(0, 3).map((s) => (
            <div key={s.value}>
              <div className="font-serif text-2xl font-semibold text-accent sm:text-3xl">
                {s.value}
              </div>
              <div className="mt-1 text-xs text-white/70 sm:text-sm">
                {t(s.label)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
