'use client'

import Image from 'next/image'
import { Phone, Mail, MapPin } from 'lucide-react'
import { useLanguage } from './language-provider'
import { dict } from '@/lib/vkd-content'

export function Footer() {
  const { t, lang } = useLanguage()

  return (
    <footer id="contact" className="scroll-mt-20 bg-forest text-forest-foreground">
      <div className="mx-auto max-w-7xl px-4 py-16 md:px-8 md:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="relative block h-14 w-14 overflow-hidden rounded-full bg-white/95 ring-1 ring-accent/40">
                <Image
                  src="/vkd/logo.png"
                  alt="VKD Group logo"
                  fill
                  sizes="56px"
                  className="object-contain p-1.5"
                />
              </span>
              <div className="font-serif text-lg font-semibold">VKD GROUP</div>
            </div>
            <p className="mt-5 max-w-sm text-sm font-medium leading-relaxed text-forest-foreground/80">
              {t(dict.footer.company)}
            </p>
            <ul className="mt-6 space-y-3 text-sm text-forest-foreground/75">
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 shrink-0 text-accent" />
                <a href="tel:1800282866" className="hover:text-accent">
                  1800 28 28 66
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0 text-accent" />
                <a href="mailto:info@vkdnature.com" className="hover:text-accent">
                  info@vkdnature.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <span>{dict.footer.address}</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-base font-semibold text-accent">
              {t(dict.footer.about)}
            </h3>
            <ul className="mt-5 space-y-3 text-sm text-forest-foreground/75">
              {dict.footer.aboutLinks[lang].map((label) => (
                <li key={label}>
                  <a href="#heritage" className="transition-colors hover:text-accent">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-base font-semibold text-accent">
              {t(dict.footer.connect)}
            </h3>
            <ul className="mt-5 space-y-3 text-sm text-forest-foreground/75">
              {dict.footer.connectLinks[lang].map((label) => (
                <li key={label}>
                  <a href="#research" className="transition-colors hover:text-accent">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-forest-foreground/15 pt-8 text-xs text-forest-foreground/60 sm:flex-row">
          <p>
            Copyright {new Date().getFullYear()} &copy; VKD GROUP. {t(dict.footer.rights)}
          </p>
          <p>Ngoc Linh Ginseng Vietnam Medical Group</p>
        </div>
      </div>
    </footer>
  )
}
