'use client'

import { FileText, Download, FlaskConical } from 'lucide-react'
import { useLanguage } from './language-provider'

const saponinMatrix = [
  { label: 'Total saponins', ngocLinh: 92, korean: 60 },
  { label: 'Majonoside R2 (MR2)', ngocLinh: 78, korean: 4 },
  { label: 'Anti-stress activity', ngocLinh: 88, korean: 55 },
  { label: 'Immune modulation', ngocLinh: 84, korean: 62 },
]

const studies = [
  {
    title: {
      en: 'Anti-tumor properties of Ngoc Linh Ginseng saponins',
      vi: 'Đặc tính kháng u của saponin Sâm Ngọc Linh',
    },
    date: '2025',
    author: 'VKD Medical Board',
  },
  {
    title: {
      en: 'Majonoside R2 efficacy in chronic stress management',
      vi: 'Hiệu quả của Majonoside R2 trong kiểm soát stress mạn tính',
    },
    date: '2024',
    author: 'VKD Medical Board',
  },
  {
    title: {
      en: 'Immunomodulatory effects of Panax vietnamensis extract',
      vi: 'Tác dụng điều hòa miễn dịch của cao Panax vietnamensis',
    },
    date: '2024',
    author: 'VKD Medical Board',
  },
]

export function Research() {
  const { t } = useLanguage()

  return (
    <section id="research" className="scroll-mt-20 bg-forest py-20 text-forest-foreground md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-accent">
            <FlaskConical className="h-4 w-4" />
            Clinical & Medical Research Hub
          </span>
          <h2 className="mt-4 text-balance font-serif text-3xl font-semibold md:text-4xl lg:text-5xl">
            {t({
              en: 'The science behind the treasure',
              vi: 'Khoa học đằng sau báu vật',
            })}
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-forest-foreground/70">
            {t({
              en: 'Ngoc Linh Ginseng carries the rare Majonoside R2 saponin \u2014 found almost nowhere else on Earth \u2014 setting it apart from Korean Red Ginseng.',
              vi: 'Sâm Ngọc Linh chứa hoạt chất quý Majonoside R2 \u2014 gần như không tìm thấy ở loài sâm nào khác \u2014 tạo nên khác biệt so với Hồng Sâm Hàn Quốc.',
            })}
          </p>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="rounded-sm border border-forest-foreground/15 bg-forest-foreground/5 p-6 md:p-8">
            <h3 className="font-serif text-xl font-semibold">
              {t({ en: 'Saponin Matrix', vi: 'Ma Trận Saponin' })}
            </h3>
            <p className="mt-1 text-sm text-forest-foreground/60">
              {t({
                en: 'Ngoc Linh Ginseng vs. Korean Red Ginseng (relative index)',
                vi: 'Sâm Ngọc Linh so với Hồng Sâm Hàn Quốc (chỉ số tương đối)',
              })}
            </p>

            <div className="mt-8 space-y-6">
              {saponinMatrix.map((row) => (
                <div key={row.label}>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="font-medium">{row.label}</span>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-3">
                      <span className="w-16 shrink-0 text-xs text-accent">Ngoc Linh</span>
                      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-forest-foreground/10">
                        <div
                          className="h-full rounded-full bg-accent"
                          style={{ width: `${row.ngocLinh}%` }}
                        />
                      </div>
                      <span className="w-8 text-right text-xs tabular-nums">{row.ngocLinh}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="w-16 shrink-0 text-xs text-forest-foreground/50">Korean</span>
                      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-forest-foreground/10">
                        <div
                          className="h-full rounded-full bg-forest-foreground/40"
                          style={{ width: `${row.korean}%` }}
                        />
                      </div>
                      <span className="w-8 text-right text-xs tabular-nums text-forest-foreground/50">
                        {row.korean}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-serif text-xl font-semibold">
              {t({ en: 'Clinical Studies', vi: 'Nghiên Cứu Lâm Sàng' })}
            </h3>
            <div className="mt-6 space-y-4">
              {studies.map((s) => (
                <article
                  key={s.date + t(s.title)}
                  className="flex items-start gap-4 rounded-sm border border-forest-foreground/15 bg-forest-foreground/5 p-5 transition-colors hover:bg-forest-foreground/10"
                >
                  <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent">
                    <FileText className="h-5 w-5" />
                  </span>
                  <div className="flex-1">
                    <h4 className="font-serif text-base font-semibold leading-snug">
                      {t(s.title)}
                    </h4>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-forest-foreground/60">
                      <span className="rounded-full bg-accent/15 px-2 py-0.5 text-accent">
                        {s.author}
                      </span>
                      <span>{s.date}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1 rounded-full border border-forest-foreground/25 px-3 py-1.5 text-xs font-semibold transition-colors hover:border-accent hover:text-accent"
                  >
                    <Download className="h-3.5 w-3.5" />
                    PDF
                  </button>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
