'use client'

import Image from 'next/image'
import { useLanguage } from './language-provider'
import { dict } from '@/lib/vkd-content'

export function Heritage() {
  const { t } = useLanguage()

  return (
    <section id="heritage" className="scroll-mt-20 bg-background py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-sm">
              <Image
                src="/vkd/cay-sam.png"
                alt="VKD Group Premium Ngoc Linh Ginseng Root grown in Kon Tum deep forest"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-4 hidden w-48 overflow-hidden rounded-sm border-4 border-background shadow-xl sm:block">
              <div className="relative aspect-[4/3]">
                <Image
                  src="/vkd/farm2.jpg"
                  alt="VKD Group Ngoc Linh Ginseng plantation in the Quang Nam highlands"
                  fill
                  sizes="192px"
                  className="object-cover"
                />
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
              {t(dict.heritage.eyebrow)}
            </span>
            <h2 className="mt-4 text-balance font-serif text-3xl font-semibold leading-tight text-forest md:text-4xl lg:text-5xl">
              {t(dict.heritage.title)}
            </h2>
            <p className="mt-6 max-w-xl text-pretty leading-relaxed text-muted-foreground">
              {t(dict.heritage.body)}
            </p>

            <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-sm bg-border">
              {dict.heritage.stats.map((s) => (
                <div key={s.value} className="bg-card p-6">
                  <div className="font-serif text-3xl font-semibold text-forest">
                    {s.value}
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    {t(s.label)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
