import { Quote, Star } from 'lucide-react';
import type { Language } from '../i18n/translations';
import { translations } from '../i18n/translations';

interface TestimonialsProps {
  lang: Language;
}

export default function Testimonials({ lang }: TestimonialsProps) {
  const t = translations[lang];
  const isRTL = lang === 'ar';

  return (
    <section className="section-padding bg-white" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="container-wide">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-gold-100 rounded-full mb-6">
            <span className="w-2 h-2 bg-gold-500 rounded-full" />
            <span className="text-xs font-semibold tracking-wider uppercase text-gold-700">
              {t.testimonials.label}
            </span>
          </div>
          <h2 className="font-display text-display-sm md:text-display-md text-forest-900">
            {t.testimonials.title}
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {t.testimonials.items.map((item, index) => (
            <figure
              key={index}
              className="relative flex flex-col rounded-2xl border border-cream-200 bg-cream-50 p-8 hover:shadow-elegant-lg hover:border-gold-300 transition-all duration-300"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-gold-400/25" />
              <div className="flex gap-0.5 text-gold-400 mb-5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <blockquote className="flex-1 text-forest-700 leading-relaxed">
                {item.quote}
              </blockquote>
              <figcaption className="mt-6 pt-5 border-t border-cream-200">
                <div className="font-display text-base font-semibold text-forest-900">
                  {item.name}
                </div>
                <div className="text-sm text-forest-500">{item.role}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
