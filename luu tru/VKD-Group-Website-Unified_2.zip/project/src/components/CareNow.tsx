import { useState } from 'react';
import {
  Sunrise, Moon, Flame, ShoppingBag, RefreshCcw,
  Sparkles, ChevronRight, CalendarCheck,
} from 'lucide-react';
import type { HealthGoal, TargetAudience } from '../data/mockData';
import { products, healthGoalLabels, audienceLabels } from '../data/mockData';
import type { Language } from '../i18n/translations';

interface CareNowProps {
  lang: Language;
  onNavigate: (page: string) => void;
}

const dayLabels = {
  vi: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
  en: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
};

const goalIconMap: Record<HealthGoal, string> = {
  energy: '⚡',
  stress: '🧘',
  immunity: '🛡️',
  youth: '✨',
};

export default function CareNow({ lang, onNavigate }: CareNowProps) {
  const isVi = lang === 'vi';

  const [goal, setGoal] = useState<HealthGoal | null>(null);
  const [audience, setAudience] = useState<TargetAudience | null>(null);
  const [takenToday, setTakenToday] = useState<boolean[]>(new Array(7).fill(false));

  const goals = Object.keys(healthGoalLabels) as HealthGoal[];
  const audiences = Object.keys(audienceLabels) as TargetAudience[];
  const days = isVi ? dayLabels.vi : dayLabels.en;
  const todayIdx = (new Date().getDay() + 6) % 7; // Monday-first index

  const recommended = goal
    ? products.find((p) => p.healthGoal === goal && (!audience || p.audiences.includes(audience))) ??
      products.find((p) => p.healthGoal === goal)
    : null;

  const streak = takenToday.filter(Boolean).length;

  const toggleDay = (idx: number) => {
    if (idx > todayIdx) return; // can't check future days
    setTakenToday((prev) => prev.map((v, i) => (i === idx ? !v : v)));
  };

  const hasProfile = !!goal;

  return (
    <div className="min-h-screen bg-cream-50 pt-28 pb-20">
      <div className="container-wide max-w-5xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-forest-100 rounded-full mb-3">
              <Sparkles className="w-3.5 h-3.5 text-forest-700" />
              <span className="text-xs font-semibold uppercase tracking-wider text-forest-700">
                VKD Care Now
              </span>
            </div>
            <h1 className="font-display text-display-sm text-forest-900">
              {isVi ? 'Chăm Sóc Sức Khỏe Của Tôi' : 'My Health Care'}
            </h1>
            <p className="text-forest-500 mt-2 max-w-lg">
              {isVi
                ? 'Thiết lập hồ sơ, theo dõi lịch dùng sâm hằng ngày và nhận đề xuất cá nhân hóa — như một huấn luyện viên sức khỏe riêng.'
                : 'Set your profile, track your daily ginseng routine, and get personalized guidance — like a private wellness coach.'}
            </p>
          </div>
          <button onClick={() => onNavigate('loyalty')} className="text-sm font-semibold text-forest-700 hover:text-gold-600 inline-flex items-center gap-1">
            {isVi ? 'Xem Hội Viên' : 'View Membership'}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {!hasProfile && (
          <div className="bg-white rounded-3xl shadow-elegant-lg border border-cream-200 p-6 md:p-10">
            <h2 className="font-display text-2xl text-forest-900 mb-1">
              {isVi ? 'Bước 1: Bạn là ai?' : 'Step 1: Who are you?'}
            </h2>
            <p className="text-forest-500 text-sm mb-6">
              {isVi ? 'Chọn để nhận lịch dùng sâm phù hợp' : 'Choose to get a matching ginseng routine'}
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
              {audiences.map((a) => (
                <button
                  key={a}
                  onClick={() => setAudience(a)}
                  className={`p-4 rounded-xl border-2 text-sm font-semibold transition-all ${
                    audience === a
                      ? 'border-gold-400 bg-gold-50 text-forest-900'
                      : 'border-cream-200 text-forest-600 hover:border-gold-300'
                  }`}
                >
                  {isVi ? audienceLabels[a].vi : audienceLabels[a].en}
                </button>
              ))}
            </div>

            <h2 className="font-display text-2xl text-forest-900 mb-1">
              {isVi ? 'Bước 2: Mục tiêu sức khỏe?' : 'Step 2: Your health goal?'}
            </h2>
            <p className="text-forest-500 text-sm mb-6">
              {isVi ? 'Chọn mục tiêu chính bạn muốn cải thiện' : 'Choose your primary wellness goal'}
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {goals.map((g) => (
                <button
                  key={g}
                  onClick={() => setGoal(g)}
                  className="p-4 rounded-xl border-2 border-cream-200 hover:border-gold-300 text-left transition-all"
                >
                  <span className="block text-xl mb-1">{goalIconMap[g]}</span>
                  <span className="text-sm font-semibold text-forest-900">
                    {isVi ? healthGoalLabels[g].vi : healthGoalLabels[g].en}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {hasProfile && recommended && (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left: profile + regimen */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-gradient-to-br from-forest-900 to-forest-950 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-gold-400/10 -translate-y-1/2 translate-x-1/2" />
                <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <span className="text-gold-300 text-xs font-semibold uppercase tracking-wider">
                      {isVi ? 'Hồ sơ của bạn' : 'Your profile'}
                    </span>
                    <h3 className="font-display text-xl mt-1">
                      {audience ? (isVi ? audienceLabels[audience].vi : audienceLabels[audience].en) : ''}
                      {' · '}
                      {isVi ? healthGoalLabels[goal!].vi : healthGoalLabels[goal!].en}
                    </h3>
                  </div>
                  <button
                    onClick={() => { setGoal(null); setAudience(null); }}
                    className="inline-flex items-center gap-2 text-xs text-white/70 hover:text-white border border-white/20 rounded-full px-3 py-1.5"
                  >
                    <RefreshCcw className="w-3 h-3" />
                    {isVi ? 'Đổi hồ sơ' : 'Edit'}
                  </button>
                </div>
              </div>

              {/* Daily regimen */}
              <div className="bg-white rounded-3xl border border-cream-200 shadow-elegant p-6 md:p-8">
                <h3 className="font-display text-xl text-forest-900 mb-5">
                  {isVi ? 'Lịch Dùng Sâm Hằng Ngày' : 'Daily Ginseng Routine'}
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 p-4 rounded-xl bg-cream-50 border border-cream-200">
                    <Sunrise className="w-5 h-5 text-gold-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-forest-400 mb-1">
                        {isVi ? 'Buổi Sáng' : 'Morning'}
                      </p>
                      <p className="text-forest-800 text-sm">
                        {isVi ? recommended.nameVi : recommended.name}
                      </p>
                      <p className="text-forest-400 text-xs mt-0.5">{recommended.activeIngredient}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-4 rounded-xl bg-cream-50 border border-cream-200">
                    <Moon className="w-5 h-5 text-forest-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-forest-400 mb-1">
                        {isVi ? 'Buổi Tối' : 'Evening'}
                      </p>
                      <p className="text-forest-800 text-sm">
                        {isVi ? 'Trà Sâm Ngọc Linh (thư giãn)' : 'Ngoc Linh Ginseng Tea (relax)'}
                      </p>
                      <p className="text-forest-400 text-xs mt-0.5">
                        {isVi ? 'Giúp ngủ ngon, phục hồi qua đêm' : 'Supports sleep & overnight recovery'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 mt-6">
                  <button onClick={() => onNavigate('autoship')} className="btn-primary text-sm inline-flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4" />
                    {isVi ? 'Đặt Giao Tự Động' : 'Set Up Autoship'}
                  </button>
                  <button onClick={() => onNavigate('catalog')} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border-2 border-forest-900 text-forest-900 text-sm font-semibold hover:bg-forest-900 hover:text-white transition-colors">
                    {isVi ? 'Xem Sản Phẩm' : 'Browse Products'}
                  </button>
                </div>
              </div>

              {/* Weekly tracker */}
              <div className="bg-white rounded-3xl border border-cream-200 shadow-elegant p-6 md:p-8">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-display text-xl text-forest-900">
                    {isVi ? 'Theo Dõi Tuần Này' : 'This Week'}
                  </h3>
                  <div className="inline-flex items-center gap-1.5 text-gold-600 text-sm font-semibold">
                    <Flame className="w-4 h-4" />
                    {streak}/7 {isVi ? 'ngày' : 'days'}
                  </div>
                </div>
                <div className="grid grid-cols-7 gap-2">
                  {days.map((d, i) => {
                    const isFuture = i > todayIdx;
                    const isToday = i === todayIdx;
                    return (
                      <button
                        key={d}
                        disabled={isFuture}
                        onClick={() => toggleDay(i)}
                        className={`flex flex-col items-center gap-2 py-3 rounded-xl border-2 transition-all ${
                          takenToday[i]
                            ? 'bg-forest-900 border-forest-900 text-white'
                            : isFuture
                            ? 'border-cream-200 text-forest-300 cursor-not-allowed'
                            : 'border-cream-300 text-forest-600 hover:border-gold-300'
                        } ${isToday ? 'ring-2 ring-gold-400 ring-offset-2' : ''}`}
                      >
                        <span className="text-[10px] font-semibold uppercase">{d}</span>
                        <CalendarCheck className={`w-4 h-4 ${takenToday[i] ? 'text-gold-300' : ''}`} />
                      </button>
                    );
                  })}
                </div>
                <p className="text-forest-400 text-xs mt-4">
                  {isVi
                    ? 'Bấm vào một ngày để đánh dấu đã dùng sâm hôm đó.'
                    : 'Tap a day to mark that you took your ginseng.'}
                </p>
              </div>
            </div>

            {/* Right: recommended product card */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl border border-cream-200 shadow-elegant-lg overflow-hidden">
                <div className="relative aspect-square bg-cream-100">
                  <img
                    src={recommended.image}
                    alt={isVi ? recommended.nameVi : recommended.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-3 left-3 bg-gold-400 text-forest-900 text-[10px] font-bold px-2.5 py-1 rounded-full">
                    {isVi ? 'Đề Xuất Cho Bạn' : 'Recommended For You'}
                  </span>
                </div>
                <div className="p-5">
                  <h4 className="font-display text-lg text-forest-900 mb-1">
                    {isVi ? recommended.nameVi : recommended.name}
                  </h4>
                  <p className="text-forest-500 text-sm">{isVi ? recommended.descriptionVi : recommended.description}</p>
                </div>
              </div>

              <div className="bg-cream-100 rounded-2xl p-5 text-sm text-forest-600 leading-relaxed">
                {isVi
                  ? 'Lưu ý: Đây là gợi ý mang tính tham khảo, không thay thế tư vấn y khoa. Liên hệ Hội đồng Y khoa VKD nếu bạn có bệnh nền hoặc đang dùng thuốc điều trị.'
                  : 'Note: This is general guidance, not medical advice. Contact the VKD Medical Board if you have underlying conditions or take prescription medication.'}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
