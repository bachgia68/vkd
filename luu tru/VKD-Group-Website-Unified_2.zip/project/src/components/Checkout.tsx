import { useState } from 'react';
import { ArrowLeft, ArrowRight, CreditCard, Truck, ShieldCheck, CheckCircle, Loader, AlertCircle, DollarSign } from 'lucide-react';
import { useCart } from '../context/CartContext';
import type { Language } from '../i18n/translations';

interface CheckoutProps {
  lang: Language;
  onNavigate: (page: string) => void;
  onOrderSuccess: (orderId: string) => void;
}

type PaymentMethod = 'stripe' | 'paypal' | 'vnpay' | 'momo';
type PaymentState = 'idle' | 'processing' | 'verifying' | 'success' | 'failed';
type Region = 'vn' | 'us' | 'eu' | 'jp' | 'cn';

const regionConfig: Record<Region, { currency: string; symbol: string; shippingBase: number; shippingExpress: number; taxRate: number; priceKey: 'priceVND' | 'priceUSD' | 'priceEUR' | 'priceJPY' | 'priceCNY' }> = {
  vn: { currency: 'VND', symbol: '₫', shippingBase: 35000,  shippingExpress: 80000,  taxRate: 0.08, priceKey: 'priceVND' },
  us: { currency: 'USD', symbol: '$', shippingBase: 18,      shippingExpress: 38,     taxRate: 0.09, priceKey: 'priceUSD' },
  eu: { currency: 'EUR', symbol: '€', shippingBase: 15,      shippingExpress: 32,     taxRate: 0.10, priceKey: 'priceEUR' },
  jp: { currency: 'JPY', symbol: '¥', shippingBase: 1800,    shippingExpress: 3800,   taxRate: 0.10, priceKey: 'priceJPY' },
  cn: { currency: 'CNY', symbol: '¥', shippingBase: 120,     shippingExpress: 280,    taxRate: 0.09, priceKey: 'priceCNY' },
};

function fmtPrice(amount: number, region: Region) {
  const { symbol, currency } = regionConfig[region];
  if (currency === 'VND' || currency === 'JPY') {
    return `${symbol}${Math.round(amount).toLocaleString()}`;
  }
  return `${symbol}${amount.toFixed(2)}`;
}

export default function Checkout({ lang, onNavigate, onOrderSuccess }: CheckoutProps) {
  const { items, subtotalVND, clearCart } = useCart();
  const isVi = lang === 'vi';

  const [region, setRegion] = useState<Region>('vn');
  const [expressShipping, setExpressShipping] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('stripe');
  const [paymentState, setPaymentState] = useState<PaymentState>('idle');

  const [form, setForm] = useState({ name: '', email: '', phone: '', address: '', city: '', country: 'Vietnam' });

  const rc = regionConfig[region];
  const subtotal = region === 'vn' ? subtotalVND : items.reduce((s, item) => s + (item[rc.priceKey] as number) * item.quantity, 0);
  const shipping = expressShipping ? rc.shippingExpress : rc.shippingBase;
  const tax = subtotal * rc.taxRate;
  const total = subtotal + shipping + tax;

  const handlePlaceOrder = async () => {
    if (!form.name || !form.email || !form.address) return;
    setPaymentState('processing');
    await new Promise(r => setTimeout(r, 1800));
    setPaymentState('verifying');
    await new Promise(r => setTimeout(r, 1400));
    const success = Math.random() > 0.1;
    if (success) {
      setPaymentState('success');
      const orderId = 'VKD-' + Date.now().toString(36).toUpperCase();
      clearCart();
      await new Promise(r => setTimeout(r, 900));
      onOrderSuccess(orderId);
    } else {
      setPaymentState('failed');
    }
  };

  const paymentOptions: { key: PaymentMethod; label: string; logo: string; type: string }[] = [
    { key: 'stripe',  label: 'Credit / Debit Card', logo: '💳', type: 'International' },
    { key: 'paypal',  label: 'PayPal',              logo: '🅿',  type: 'International' },
    { key: 'vnpay',   label: 'VNPAY',               logo: '🇻🇳', type: 'Domestic (VN)' },
    { key: 'momo',    label: 'MoMo Wallet',         logo: '💜', type: 'Domestic (VN)' },
  ];

  if (paymentState === 'processing' || paymentState === 'verifying') {
    return (
      <div className="min-h-screen bg-cream-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-forest-100 flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Loader className="w-10 h-10 text-forest-600 animate-spin" />
          </div>
          <h2 className="font-display text-2xl font-bold text-forest-900 mb-2">
            {paymentState === 'processing'
              ? (isVi ? 'Đang Xử Lý Thanh Toán...' : 'Processing Payment...')
              : (isVi ? 'Đang Xác Minh Giao Dịch...' : 'Verifying Transaction...')}
          </h2>
          <p className="text-forest-500">{isVi ? 'Vui lòng không đóng trang này.' : 'Please do not close this page.'}</p>
        </div>
      </div>
    );
  }

  if (paymentState === 'failed') {
    return (
      <div className="min-h-screen bg-cream-50 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="font-display text-2xl font-bold text-forest-900 mb-2">
            {isVi ? 'Thanh Toán Thất Bại' : 'Payment Failed'}
          </h2>
          <p className="text-forest-500 mb-6">
            {isVi ? 'Giao dịch không thành công. Vui lòng kiểm tra lại thông tin thanh toán.' : 'Transaction was declined. Please check your payment details and try again.'}
          </p>
          <button onClick={() => setPaymentState('idle')} className="btn-primary">
            {isVi ? 'Thử Lại' : 'Try Again'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream-50 pt-24 pb-16">
      <div className="container-wide max-w-6xl">
        {/* Back */}
        <button onClick={() => onNavigate('catalog')} className="flex items-center gap-2 text-forest-500 hover:text-forest-800 mb-8 transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" />
          {isVi ? 'Quay Lại Cửa Hàng' : 'Back to Shop'}
        </button>

        <div className="grid lg:grid-cols-[1fr_420px] gap-8">

          {/* ── LEFT: Forms ── */}
          <div className="space-y-6">
            {/* Region picker */}
            <div className="bg-white rounded-2xl p-6 shadow-elegant">
              <h3 className="font-display font-semibold text-forest-900 mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-gold-500" />
                {isVi ? 'Khu Vực & Tiền Tệ' : 'Region & Currency'}
              </h3>
              <div className="flex flex-wrap gap-2">
                {(Object.keys(regionConfig) as Region[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setRegion(r)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${region === r ? 'bg-forest-900 text-cream-50' : 'bg-cream-100 text-forest-600 hover:bg-forest-50'}`}
                  >
                    {r.toUpperCase()} · {regionConfig[r].currency}
                  </button>
                ))}
              </div>
            </div>

            {/* Shipping */}
            <div className="bg-white rounded-2xl p-6 shadow-elegant">
              <h3 className="font-display font-semibold text-forest-900 mb-4 flex items-center gap-2">
                <Truck className="w-5 h-5 text-gold-500" />
                {isVi ? 'Thông Tin Giao Hàng' : 'Shipping Details'}
              </h3>
              <div className="grid sm:grid-cols-2 gap-4 mb-4">
                {[
                  { key: 'name',    label: isVi ? 'Họ Tên' : 'Full Name',      placeholder: isVi ? 'Nguyễn Văn A' : 'John Smith' },
                  { key: 'email',   label: 'Email',                             placeholder: 'your@email.com' },
                  { key: 'phone',   label: isVi ? 'Số Điện Thoại' : 'Phone',   placeholder: '+84 ...' },
                  { key: 'country', label: isVi ? 'Quốc Gia' : 'Country',      placeholder: 'Vietnam' },
                ].map(({ key, label, placeholder }) => (
                  <div key={key}>
                    <label className="block text-xs font-semibold text-forest-600 mb-1.5 uppercase tracking-wide">{label}</label>
                    <input
                      value={form[key as keyof typeof form]}
                      onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                      placeholder={placeholder}
                      className="w-full px-4 py-3 rounded-xl border border-cream-200 focus:border-forest-400 focus:ring-2 focus:ring-forest-100 outline-none text-forest-900 text-sm bg-cream-50 transition-all"
                    />
                  </div>
                ))}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-forest-600 mb-1.5 uppercase tracking-wide">{isVi ? 'Địa Chỉ' : 'Street Address'}</label>
                  <input
                    value={form.address}
                    onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
                    placeholder={isVi ? '123 Đường Lê Lợi, Quận 1...' : '123 Main Street...'}
                    className="w-full px-4 py-3 rounded-xl border border-cream-200 focus:border-forest-400 focus:ring-2 focus:ring-forest-100 outline-none text-forest-900 text-sm bg-cream-50 transition-all"
                  />
                </div>
              </div>

              {/* Shipping type */}
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  onClick={() => setExpressShipping(false)}
                  className={`p-4 rounded-xl border-2 text-left transition-all ${!expressShipping ? 'border-forest-600 bg-forest-50' : 'border-cream-200 hover:border-forest-300'}`}
                >
                  <div className="font-semibold text-forest-900 text-sm mb-0.5">{isVi ? 'Giao Tiêu Chuẩn' : 'Standard Delivery'}</div>
                  <div className="text-forest-500 text-xs mb-1">{region === 'vn' ? 'GHTK Express · 2-3 ngày' : 'DHL Standard · 7–14 days'}</div>
                  <div className="font-bold text-forest-800">{fmtPrice(rc.shippingBase, region)}</div>
                </button>
                <button
                  onClick={() => setExpressShipping(true)}
                  className={`p-4 rounded-xl border-2 text-left transition-all ${expressShipping ? 'border-gold-500 bg-gold-50' : 'border-cream-200 hover:border-gold-300'}`}
                >
                  <div className="font-semibold text-forest-900 text-sm mb-0.5">{isVi ? 'Giao Hỏa Tốc' : 'Premium Express'}</div>
                  <div className="text-forest-500 text-xs mb-1">{region === 'vn' ? 'GHTK Same Day · Trong ngày' : 'DHL Express · 2–4 days'}</div>
                  <div className="font-bold text-gold-600">{fmtPrice(rc.shippingExpress, region)}</div>
                </button>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-2xl p-6 shadow-elegant">
              <h3 className="font-display font-semibold text-forest-900 mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-gold-500" />
                {isVi ? 'Phương Thức Thanh Toán' : 'Payment Method'}
              </h3>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {paymentOptions.map((opt) => (
                  <button
                    key={opt.key}
                    onClick={() => setPaymentMethod(opt.key)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${paymentMethod === opt.key ? 'border-forest-600 bg-forest-50' : 'border-cream-200 hover:border-forest-300'}`}
                  >
                    <div className="text-2xl mb-1">{opt.logo}</div>
                    <div className="font-semibold text-forest-900 text-sm">{opt.label}</div>
                    <div className="text-forest-400 text-xs">{opt.type}</div>
                  </button>
                ))}
              </div>
              {(paymentMethod === 'stripe') && (
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-forest-600 mb-1.5 uppercase tracking-wide">{isVi ? 'Số Thẻ' : 'Card Number'}</label>
                    <input placeholder="4242 4242 4242 4242" className="w-full px-4 py-3 rounded-xl border border-cream-200 focus:border-forest-400 outline-none text-forest-900 text-sm bg-cream-50" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-forest-600 mb-1.5 uppercase tracking-wide">MM/YY</label>
                      <input placeholder="12/27" className="w-full px-4 py-3 rounded-xl border border-cream-200 focus:border-forest-400 outline-none text-forest-900 text-sm bg-cream-50" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-forest-600 mb-1.5 uppercase tracking-wide">CVV</label>
                      <input placeholder="123" className="w-full px-4 py-3 rounded-xl border border-cream-200 focus:border-forest-400 outline-none text-forest-900 text-sm bg-cream-50" />
                    </div>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-2 mt-4 p-3 rounded-xl bg-forest-50">
                <ShieldCheck className="w-4 h-4 text-forest-600 flex-shrink-0" />
                <p className="text-forest-600 text-xs">{isVi ? 'Thanh toán được mã hóa 256-bit SSL. VKD không lưu thông tin thẻ của bạn.' : '256-bit SSL encrypted. VKD never stores your card details.'}</p>
              </div>
            </div>
          </div>

          {/* ── RIGHT: Order Summary ── */}
          <div>
            <div className="bg-white rounded-2xl shadow-elegant overflow-hidden sticky top-24">
              <div className="bg-forest-900 px-6 py-4">
                <h3 className="font-display font-semibold text-white">{isVi ? 'Tóm Tắt Đơn Hàng' : 'Order Summary'}</h3>
              </div>
              <div className="p-6">
                <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                  {items.map(item => (
                    <div key={item.id} className="flex gap-3 items-center">
                      <img src={item.image} alt={item.name} className="w-14 h-16 rounded-lg object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-forest-900 text-xs font-medium leading-snug line-clamp-2">{isVi ? item.nameVi : item.name}</p>
                        <p className="text-forest-400 text-xs mt-0.5">×{item.quantity}</p>
                      </div>
                      <div className="text-forest-900 text-sm font-bold flex-shrink-0">
                        {fmtPrice((item[rc.priceKey] as number) * item.quantity, region)}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 pt-4 border-t border-cream-200">
                  {[
                    { label: isVi ? 'Tạm Tính' : 'Subtotal', value: fmtPrice(subtotal, region) },
                    { label: isVi ? `Vận chuyển (${expressShipping ? 'Hỏa tốc' : 'Tiêu chuẩn'})` : `Shipping (${expressShipping ? 'Express' : 'Standard'})`, value: fmtPrice(shipping, region) },
                    { label: isVi ? `Thuế (${(rc.taxRate * 100).toFixed(0)}%)` : `Tax (${(rc.taxRate * 100).toFixed(0)}%)`, value: fmtPrice(tax, region) },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between text-sm text-forest-600">
                      <span>{label}</span><span>{value}</span>
                    </div>
                  ))}
                  <div className="flex justify-between pt-3 border-t border-cream-200">
                    <span className="font-bold text-forest-900">{isVi ? 'Tổng Cộng' : 'Total'}</span>
                    <span className="font-display font-bold text-forest-900 text-xl">{fmtPrice(total, region)}</span>
                  </div>
                </div>

                <button
                  onClick={handlePlaceOrder}
                  disabled={items.length === 0}
                  className="btn-gold w-full justify-center mt-6 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <CheckCircle className="w-5 h-5" />
                  {isVi ? 'Đặt Hàng' : 'Place Order'}
                  <ArrowRight className="w-4 h-4" />
                </button>

                {items.length === 0 && (
                  <p className="text-center text-forest-400 text-xs mt-3">{isVi ? 'Giỏ hàng trống' : 'Your cart is empty'}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
