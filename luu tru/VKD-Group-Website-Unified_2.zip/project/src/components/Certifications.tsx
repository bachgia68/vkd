import { Globe } from 'lucide-react';
import type { Language } from '../i18n/translations';
import { translations } from '../i18n/translations';

interface CertificationsProps {
  lang: Language;
}

export default function Certifications({ lang }: CertificationsProps) {
  const t = translations[lang];

  const certifications = [
    {
      image: '/assets/images/cert-cgmp.jpg',
      name: 'cGMP',
      desc: 'Current Good Manufacturing Practice',
    },
    {
      image: '/assets/images/cert-haccp.jpg',
      name: 'HACCP',
      desc: 'Hazard Analysis Critical Control Points',
    },
    {
      image: '/assets/images/cert-iso9001.jpg',
      name: 'ISO 9001',
      desc: 'Quality Management System',
    },
  ];

  return (
    <section className="section-padding-sm bg-cream-100">
      <div className="container-wide">
        {/* Header */}
        <div className="text-center mb-10">
          <h3 className="font-display text-2xl text-forest-900 mb-2">
            {t.certifications.title}
          </h3>
          <p className="text-forest-500">{t.certifications.subtitle}</p>
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {certifications.map((cert, index) => (
            <figure
              key={index}
              className="group overflow-hidden rounded-xl bg-white border border-cream-300 hover:shadow-elegant-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-cream-200">
                <img
                  src={cert.image}
                  alt={`VKD Group ${cert.name} certificate — ${cert.desc}`}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <figcaption className="px-5 py-4 text-center border-t border-cream-200">
                <h4 className="font-display text-lg font-semibold text-forest-900">{cert.name}</h4>
                <p className="text-forest-500 text-xs mt-0.5">{cert.desc}</p>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-forest-400 text-xs uppercase tracking-wider">
          <Globe className="w-4 h-4" />
          <span>ISO 22000 · GACP-WHO · FDA-listed facility</span>
        </div>
      </div>
    </section>
  );
}
